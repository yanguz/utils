package excel.read;

public class Cell {
	public String r;
	public String s;
	public String t;
	public String v;
}
